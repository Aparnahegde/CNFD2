package com.example.Prgrm7;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


@SpringBootApplication
public class Prgrm7Application {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(Prgrm7Application.class, args);
		StudentService ss =ac.getBean(StudentService.class);
		
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("Menu\n1.Add Student\n2.View all STD\n3delete student\n4.exit\nEnter your choice");
			int choice=sc.nextInt();
			sc.nextLine();
			switch(choice) {
			case 1:
				System.out.print("student id");
				int id=sc.nextInt();
				System.out.print("usn");
				String usn=sc.next();
				System.out.print("name");
				String name=sc.next();
				System.out.print("address");
				String address=sc.next();
				ss.insert(id, usn, name, address);
				System.out.println("Student added successfully");
				break;
				case 2:
					System.out.println(ss.display());
					break;
				case 3:
					System.out.println("delete usn");
					String usn1=sc.next();
					ss.delete(usn1);
					System.out.println("stduent deleted");
					break;
				case 4:
					System.exit(0);
					break;
				default:
					System.out.println("invalid");
					
				}
			
		}
		
		
		
	}

}
