package com.example.Prgrm7;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

	
	@Autowired
	StudentRepository sr;
	public List<Student> display(){
		List<Student> slist=sr.findAll();
		return slist;
	}
	
	public String insert(int id,String usn,String name,String address ) {
		int status=0;
		Student s=new Student();
		
		s.setAddress(address);
		s.setId(id);
		s.setName(name);
		s.setUsn(usn);
		sr.save(s);
		return "inserted into the table";
	}
	public String delete(String usn) {
		List<Student> slist=sr.findAll();
		for(Student s:slist) {
			if(s.getUsn().equalsIgnoreCase(usn)) {
				sr.delete(s);
				return "student record was deleted";
			}else {
				return "student not found";
			}
			
		}
		return "";
	}
	

}
